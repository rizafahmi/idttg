(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Mailgun;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/gfk:mailgun-api/mailgun-api.js                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Mailgun = (function () {                                                                                             // 1
    'use strict';                                                                                                    // 2
                                                                                                                     // 3
    /***                                                                                                             // 4
     * Constructs a new instance of the mailgun wrapper                                                              // 5
     * @param {Object} options                                                                                       // 6
     * @param {String} options.apiKey The api key to use in communication with mailgun                               // 7
     * @param {String} options.domain The domain to use in communication with mailgun                                // 8
     * @constructor                                                                                                  // 9
     */                                                                                                              // 10
    var constructor = function (options) {                                                                           // 11
        var mailgunJS = Npm.require('mailgun-js');                                                                   // 12
                                                                                                                     // 13
        this.api = new mailgunJS({                                                                                   // 14
            apiKey: options.apiKey,                                                                                  // 15
            domain: options.domain                                                                                   // 16
        });                                                                                                          // 17
    };                                                                                                               // 18
                                                                                                                     // 19
    /***                                                                                                             // 20
     * Sends the email to mailgun                                                                                    // 21
     *                                                                                                               // 22
     * @param {Object} emailObject                                                                                   // 23
     * @param {String} [emailObject.to] Address to which to sent the email                                           // 24
     * @param {String} [emailObject.cc] Address to which to cc the email                                             // 25
     * @param {String} [emailObject.bcc] Address to which to bcc the email                                           // 26
     * @param {String} [emailObject.html] The html version of the email                                              // 27
     * @param {String} [emailObject.text] The text version of the email                                              // 28
     * @param {String} [emailObject.subject] the subject of the email                                                // 29
     * @param {Array} [emailObject.tags] Tags to sent to mailgun                                                     // 30
     * @param {Object} options [options={}] The options to use for sending the email                                 // 31
     * @param {String} [options.testmode] Adds mailgun testmode parameter                                            // 32
     * @param {String} [options.saveEmailTo] Specifies the location to save a copy of the html email to. Tries to create the directories if they don't exist yet
     * @returns {Object} result                                                                                      // 34
     * @returns {Object} result.error Object containing the error given during the sending of the mail               // 35
     * @returns {String} result.response response returned by email provider wrapper                                 // 36
     */                                                                                                              // 37
    constructor.prototype.send = function (emailObject, options) {                                                   // 38
        var Future = Npm.require('fibers/future'),                                                                   // 39
            fs = Npm.require('fs'),                                                                                  // 40
            mkdirpModule = Npm.require('mkdirp'),                                                                    // 41
            writeFile = Future.wrap(fs.writeFile),                                                                   // 42
            mkdirp = Future.wrap(mkdirpModule.mkdirp, 1),                                                            // 43
            errors = [], result;                                                                                     // 44
                                                                                                                     // 45
        options = options || {};                                                                                     // 46
                                                                                                                     // 47
        if(options.testmode) {                                                                                       // 48
            emailObject['o:testmode'] = true;                                                                        // 49
        }                                                                                                            // 50
                                                                                                                     // 51
        if (options.saveEmailTo) {                                                                                   // 52
            var targetDir = options.saveEmailTo.split('/');                                                          // 53
            targetDir.pop();                                                                                         // 54
            targetDir = targetDir.join('/');                                                                         // 55
                                                                                                                     // 56
            var mkdirResult = mkdirp(targetDir).wait();                                                              // 57
                                                                                                                     // 58
            if (mkdirResult === null) {                                                                              // 59
                writeFile(options.saveEmailTo , emailObject.html).wait();                                            // 60
            } else {                                                                                                 // 61
                errors.push('Error creating directories! Errorcode: ' + mkdirResult.code + ' path: ' + mkdirResult.path);
            }                                                                                                        // 63
        }                                                                                                            // 64
                                                                                                                     // 65
        if(emailObject.tags) {                                                                                       // 66
            emailObject['o:tag'] = _.clone(emailObject.tags);                                                        // 67
            delete emailObject.tags;                                                                                 // 68
        }                                                                                                            // 69
                                                                                                                     // 70
        if (errors.length) {                                                                                         // 71
            result = {                                                                                               // 72
                error: errors.join(',')                                                                              // 73
            };                                                                                                       // 74
        } else {                                                                                                     // 75
            result = this._send(emailObject).wait();                                                                 // 76
        }                                                                                                            // 77
                                                                                                                     // 78
        return result;                                                                                               // 79
    };                                                                                                               // 80
                                                                                                                     // 81
    constructor.prototype._send = function (emailObject) {                                                           // 82
        var Future = Npm.require('fibers/future'),                                                                   // 83
            fut = new Future();                                                                                      // 84
                                                                                                                     // 85
        this.api.messages().send(emailObject, function (error, response) {                                           // 86
            response = response || {};                                                                               // 87
            fut.return({error: error, response: response});                                                          // 88
        });                                                                                                          // 89
                                                                                                                     // 90
        return fut;                                                                                                  // 91
    };                                                                                                               // 92
                                                                                                                     // 93
    /***                                                                                                             // 94
     * Checks if a key exists if so replaces the value with a string valued 'yes' or 'no'                            // 95
     *                                                                                                               // 96
     * @param {Object} obj The object that holds the keys to convert                                                 // 97
     * @param {Array|String} keys the key(s) to convert to a value mailgun understands                               // 98
     * @private                                                                                                      // 99
     */                                                                                                              // 100
    constructor.prototype._convertBooleans = function (obj, keys) {                                                  // 101
        var value;                                                                                                   // 102
        keys = _.isArray(keys) ? keys : [keys];                                                                      // 103
                                                                                                                     // 104
                                                                                                                     // 105
        _.each(keys, function (key) {                                                                                // 106
            value = obj[key];                                                                                        // 107
                                                                                                                     // 108
            if (!_.isUndefined(value)) {                                                                             // 109
                if (_.isBoolean(value)) {                                                                            // 110
                    value = value ? 'yes' : 'no';                                                                    // 111
                } else if (_.isString(value)) {                                                                      // 112
                    value = value === 'no' ? 'no' : 'yes';                                                           // 113
                } else {                                                                                             // 114
                    value = !!value;                                                                                 // 115
                }                                                                                                    // 116
                obj[key] = value;                                                                                    // 117
            }                                                                                                        // 118
        });                                                                                                          // 119
    };                                                                                                               // 120
    /***                                                                                                             // 121
     * Converts a date string or date object to a RFC2822 timestring                                                 // 122
     * @param {Date|String} date the date to convert to a RFC2822 timestring                                         // 123
     * @returns {String} The RFC2822 Timestring                                                                      // 124
     * @private                                                                                                      // 125
     */                                                                                                              // 126
    constructor.prototype._convertDateToTimeString = function (date) {                                               // 127
        date = date instanceof Date ? date : new Date(date);                                                         // 128
        return (date / 1000).toString();                                                                             // 129
    };                                                                                                               // 130
                                                                                                                     // 131
    /***                                                                                                             // 132
     * Converts RFC2822 Timestring to a Date object                                                                  // 133
     * @param {String} timestring the RFC2822 timestring as returned by mailgun                                      // 134
     * @returns {Date} The date object                                                                               // 135
     * @private                                                                                                      // 136
     */                                                                                                              // 137
    constructor.prototype._convertTimeStringToDate = function (timestring) {                                         // 138
        return new Date(timestring * 1000);                                                                          // 139
    };                                                                                                               // 140
                                                                                                                     // 141
                                                                                                                     // 142
    /***                                                                                                             // 143
     * Checks events for the given filter.                                                                           // 144
     * @param {Object} filter [filter={}] The filter to use for retrieving the events see: http://documentation.mailgun.com/api-events.html#filter-field
     * @param {Date|String} [filter.beginDate] The beginning of the time range to select log records from. By default it is the time of the request
     * @param {Date|String} [filter.endDate] The end of the time range and the direction of the log record traversal. If end is less than begin, then traversal is performed in the timestamp descending order, otherwise in timestamp ascending order. By default, if ascending is yes, then it is a date in the distant future, otherwise a date in the distant past.
     * @param {Boolean} [filter.ascending=false] The direction of log record traversal. If end is also specified, then the relation between begin and end should agree with the ascending value, otherwise an error will be returned. The default value is deduced from the begin and end relation. If end is not specified, then the value is no, effectively defining traversal direction from begin, to the past, until the end of time.
     * @param {Boolean} [filter.pretty=true] Defaults to true on the server                                          // 149
     * @returns {Future}                                                                                             // 150
     */                                                                                                              // 151
    constructor.prototype.getEvents = function (filter) {                                                            // 152
        var Future = Npm.require('fibers/future'),                                                                   // 153
            fut = new Future(),                                                                                      // 154
            self = this;                                                                                             // 155
        filter = filter || {};                                                                                       // 156
                                                                                                                     // 157
        if (filter.beginDate) {                                                                                      // 158
            filter.begin = this._convertDateToTimeString(filter.beginDate);                                          // 159
            delete filter.beginDate;                                                                                 // 160
        }                                                                                                            // 161
                                                                                                                     // 162
        if (filter.endDate) {                                                                                        // 163
            filter.end = this._convertDateToTimeString(filter.endDate);                                              // 164
            delete filter.endDate;                                                                                   // 165
        }                                                                                                            // 166
                                                                                                                     // 167
        this._convertBooleans(filter, ['ascending', 'pretty']);                                                      // 168
                                                                                                                     // 169
        this.api.events().get(filter, function (error, response) {                                                   // 170
            response = response || {};                                                                               // 171
            var items = response.items || [];                                                                        // 172
            _.each(response.items, function (item) {                                                                 // 173
                item.date = self._convertTimeStringToDate(item.timestamp);                                           // 174
            });                                                                                                      // 175
            fut.return({error: error, items: items});                                                                // 176
        });                                                                                                          // 177
                                                                                                                     // 178
        return fut;                                                                                                  // 179
    };                                                                                                               // 180
	/***                                                                                                                // 181
	 * Iterates over the events found with the given filter and calls the appropiate handler for each event.            // 182
	 * @param {Object} filter [filter={}] The filter to use for retrieving the events see: http://documentation.mailgun.com/api-events.html#filter-field
	 * @param {Object} eventHandlers hold handlers for the different eventtypes                                         // 184
	 * @param {Function} eventHandlers.before [eventHandlers.before] Handler to be executed on all events before the actual handler is executed
	 * @param {Function} eventHandlers.accepted [eventHandlers.accepted] Handler executed on accepted event             // 186
	 * @param {Function} eventHandlers.rejected [eventHandlers.rejected] Handler executed on rejected event             // 187
	 * @param {Function} eventHandlers.delivered [eventHandlers.delivered] Handler executed on delivered event          // 188
	 * @param {Function} eventHandlers.failed [eventHandlers.failed] Handler executed on failed event                   // 189
	 * @param {Function} eventHandlers.openend [eventHandlers.openend] Handler executed on openend event                // 190
	 * @param {Function} eventHandlers.clicked [eventHandlers.clicked] Handler executed on clicked event                // 191
	 * @param {Function} eventHandlers.unsubscribed [eventHandlers.unsubscribed] Handler executed on unsubscribed event // 192
	 * @param {Function} eventHandlers.complained [eventHandlers.complained] Handler executed on complained event       // 193
	 * @param {Function} eventHandlers.stored [eventHandlers.stored] Handler executed on stored event                   // 194
	 *                                                                                                                  // 195
	 * @returns {{}}                                                                                                    // 196
	 */                                                                                                                 // 197
	constructor.prototype.handleEvents = function (filter, eventHandlers) {                                             // 198
		var result = {};                                                                                                   // 199
                                                                                                                     // 200
		if (!_.isObject(eventHandlers)) {                                                                                  // 201
			result.error = new Error('The eventHandlers argument is not a object');                                           // 202
		}                                                                                                                  // 203
                                                                                                                     // 204
		var events = this.getEvents(filter).wait(),                                                                        // 205
			supportedEventTypes = _.values(this.CONST.EVENTTYPES);                                                            // 206
                                                                                                                     // 207
		if (events.error) {                                                                                                // 208
			result.error = events.error;                                                                                      // 209
		} else {                                                                                                           // 210
			_.each(events.items, function (item) {                                                                            // 211
				if (_.isFunction(eventHandlers.before)) {                                                                        // 212
					eventHandlers.before(item);                                                                                     // 213
				}                                                                                                                // 214
                                                                                                                     // 215
				if (_.isFunction(eventHandlers[item.event])) {                                                                   // 216
					eventHandlers[item.event](item);                                                                                // 217
				}                                                                                                                // 218
			}, this);                                                                                                         // 219
		}                                                                                                                  // 220
                                                                                                                     // 221
		return result;                                                                                                     // 222
	};                                                                                                                  // 223
                                                                                                                     // 224
                                                                                                                     // 225
    constructor.prototype.CONST = {                                                                                  // 226
        EVENTTYPES: {                                                                                                // 227
            ACCEPTED: 'accepted',                                                                                    // 228
            REJECTED: 'rejected',                                                                                    // 229
            DELIVERED: 'delivered',                                                                                  // 230
            FAILED: 'failed',                                                                                        // 231
            OPENED: 'openend',                                                                                       // 232
            CLICKED: 'clicked',                                                                                      // 233
            UNSUBSCRIBED: 'unsubscribed',                                                                            // 234
            COMPLAINED: 'complained',                                                                                // 235
            STORED: 'stored'                                                                                         // 236
        },                                                                                                           // 237
		REASONS: {                                                                                                         // 238
			BOUNCE: 'bounce'                                                                                                  // 239
		},                                                                                                                 // 240
		SEVERITIES: {                                                                                                      // 241
			PERMANENT: 'permanent',                                                                                           // 242
			TEMPORARY: 'temporary'                                                                                            // 243
		}                                                                                                                  // 244
    };                                                                                                               // 245
                                                                                                                     // 246
    return constructor;                                                                                              // 247
}());                                                                                                                // 248
                                                                                                                     // 249
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['gfk:mailgun-api'] = {
  Mailgun: Mailgun
};

})();

//# sourceMappingURL=gfk_mailgun-api.js.map
