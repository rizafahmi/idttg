(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['johannesma:meteor-flexslider'] = {};

})();

//# sourceMappingURL=johannesma_meteor-flexslider.js.map
