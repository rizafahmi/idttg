(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['gquemart:meteor-reactive-fullcalendar'] = {};

})();

//# sourceMappingURL=gquemart_meteor-reactive-fullcalendar.js.map
