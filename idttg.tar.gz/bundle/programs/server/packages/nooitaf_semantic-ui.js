(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nooitaf:semantic-ui'] = {};

})();

//# sourceMappingURL=nooitaf_semantic-ui.js.map
