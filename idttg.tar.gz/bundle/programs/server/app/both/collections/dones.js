(function(){Dones = new Mongo.Collection('dones');
/*
 * Add query methods like this:
 *  Dones.findPublic = function () {
 *    return Dones.find({is_public: true});
 *  }
 */

})();
