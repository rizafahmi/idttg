(function(){Gratitudes = new Mongo.Collection('gratitudes');
/*
 * Add query methods like this:
 *  Gratitutes.findPublic = function () {
 *    return Gratitutes.find({is_public: true});
 *  }
 */

})();
