(function(){/*****************************************************************************/
/* Dones Methods */
/*****************************************************************************/

Meteor.methods({
 /*
  * Example:
  *  '/app/dones/update/email': function (email) {
  *    Users.update({_id: this.userId}, {$set: {'profile.email': email}});
  *  }
  *
  */
});

})();
