(function(){process.env['MAILGUN_API_KEY'] = "key-ba897ac3066a77b294f6735fc629eb8d";
process.env['MAILGUN_DOMAIN'] = "idttg.com";
process.env['MAILGUN_API_URL'] = "https://api.mailgun.net/v2";

})();
