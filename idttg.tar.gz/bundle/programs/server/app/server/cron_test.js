(function(){// var world = function () {
//   console.log('World!');
// }
//
// var cron = new Meteor.Cron({
//     events: {
//       "* * * * *": world
//     }
// });

})();
